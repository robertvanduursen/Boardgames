
import gwentData, random



faction = gwentData.Factions['Scoiatael'] + gwentData.Factions['Neutral']
# faction = gwentGame.Factions['Syndicate']

# can pick cards from 1 faction and Neutral
# combinedFaction = self.faction + gwentGame.Factions['Neutral']
# print(len(combinedFaction.cards))
# print(self.leader.__dict__.items())


for card in faction.cards:
    print(card.name)
    print(card.faction)
    print(card.categories)
    print(card.info)

print(len(faction.cards))

# todo: the card set is incomplete

# todo: labels are also not complete, unless derived

# C:\Program Files (x86)\GOG Galaxy\Games\Gwent\Gwent_Data\StreamingAssets